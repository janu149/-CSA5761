#!/bin/bash
echo "enter length"
read l
echo "enter base"
read b
area=$((l*b))
echo "area of rectangle"=$area
