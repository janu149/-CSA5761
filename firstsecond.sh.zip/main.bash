31.
#!/bin/bash
echo "enter frist number"
read frist
echo "enter second number"
read second
temp=$first
frist=$second
second=$temp
echo "after swapping: "
echo "frist number=$first, second
number=$second"
